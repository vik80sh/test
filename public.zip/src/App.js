import React from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import Home from './components/home/home';
import Order from './components/order/order';
import Delivery from './components/delevery/delevery';

function App() {
  let src = `https://images.unsplash.com/photo-1490211871743-069074507117?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=755&q=80`;
  return (
    <div className="App background-image" style={{backgroundImage: `url(${src})`}}>
      <Router>
        <Switch>
          <Route exact path='/' component={Home} />
          <Route exact path='/delevery' component={Delivery} />
          <Route exact path='/order' component={Order} />
          <Route exact path='/login' component={Home} />

        </Switch>
      </Router>
    </div >

  );
}

export default App;
