import React, { Component } from 'react';
import { Link } from "react-router-dom";
import './home.scss';

export default class Home extends Component {
  render() {
    let logo = `https://www.pinclipart.com/picdir/big/176-1766460_png-freeuse-download-cafe-vector-design-element-coffee.png`;

    return (
      <div className="home-wrapper" >
        <div className="container-fluid home-title-container">
          <div className="row ">
            <div className="col-sm-4 logo">
              <img src={logo} alt="logo-image" />
            </div>
            <div className="col-sm-2 home-cake devivery">
              <Link to='/delevery'>Cake Devivery</Link>
            </div>
            <div className="col-sm-2 home-cake order">
              <Link to='/order'> How to order</Link>
            </div>
            <div className="col-sm-2 home-cake check-more">
              <Link to='/check'>Check More</Link>
            </div>
            <div className="col-sm-2 home-cake login">
              <Link to='/login'> Login</Link>
            </div>
          </div>
        </div>
      </div>
    )
  }
}