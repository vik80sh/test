import React, { Component } from 'react'
import data from './../../data.json'
export default class Order extends Component {
    render() {
        return (
            <div className="order-wrapper">
                {data.map((list,index)=>{
                    return <p className="oder-title" key={index}>{list.title}</p>
                })}
            </div>
        )
    }
}
