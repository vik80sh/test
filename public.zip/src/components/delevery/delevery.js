import React, { Component } from 'react'

export default class Delivery extends Component {
    render() {
        return (
            <div>
                Delivery  DeliveryDeliv  ery Deli  veryDe livery  
            </div>
        )
    }
}
